import React from 'react'

const SingIn: React.FC = () => {
  return (
    <h1>SingIn</h1>
  )
}

export default SingIn;